public class Guess {
    private String guess;
    private double score;
    public Guess(String s, double d){
        score = d;
        guess = s;
    }
    public String getGuess(){
        return guess;
    }
    public double getScore(){
        return score;
    }

    public void setScore(double d){
        score = d;
    }
}
