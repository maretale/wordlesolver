public class Wordle {
    private String solution;
    private static String letters = "abcdefghijklmnopqrstuvwxyz";
    private static String[] alphabet;
    private static int gray = 0;
    private static int yellow = 1;
    private static int green = 2;

    public static void setAlphabet(){
        alphabet = new String[26];
        for(int i = 0; i < 26; i++){
            alphabet[i] = letters.substring(i, i+1);
        }
    }

    public Wordle(String solution){
        this.solution = solution;
    }

    public String getSolution(){
        return solution;
    }

    public int[] guess(String guess){
        int[] result = new int[5];

        //sets all letters to gray
        for(int i = 0; i < 5; i++){
            result[i] = gray;
        }

        //tests each letter one at a time if it's in the solution
        for(String l : alphabet){
            if(solution.indexOf(l)!=-1) {
                int guessCount = 0;
                int solutionCount = 0;

                //determines count of given letter in the guess
                for (int i = 0; i < 5; i++) {
                    if (guess.substring(i, i + 1).equals(l)) {
                        guessCount++;
                    }
                }

                //determines count of given letter in the solution
                for (int i = 0; i < 5; i++) {
                    if (solution.substring(i, i + 1).equals(l)) {
                        solutionCount++;
                    }
                }

                //if count>0, it colors the result correctly;
                if (guessCount > 0) {
                    int correct = 0;
                    for (int i = 0; i < 5; i++) {
                        if (solution.substring(i, i + 1).equals(guess.substring(i, i + 1)) && guess.substring(i, i + 1).equals(l)) {
                            result[i] = green;
                            correct++;
                            guessCount--;
                        }
                    }

                    for (int i = 0; i < 5; i++) {
                        if (guess.substring(i, i + 1).equals(l) && result[i] == gray && solutionCount - correct > 0 && guessCount > 0) {
                            result[i] = yellow;
                            correct++;
                            guessCount--;
                        }
                    }
                }
            }
        }
        return result;
    }

    public void guessAndPrint(String guess){
        int[] result = guess(guess);
        for(int i = 0; i < 5; i++){
            System.out.print(result[i]+" ");
        }
        System.out.println();
    }
}
