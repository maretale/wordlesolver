import java.util.ArrayList;
public class FourthGuess {
    private String guess;
    private String[] solutions;
    private ArrayList<String>[] map;

    public FourthGuess(String g, ThirdGuess t, int n){
        guess = g;
        solutions = new String[t.getMap()[n].size()];
        for(int i = 0; i < t.getMap()[n].size(); i++){
            solutions[i]=t.getMap()[n].get(i);
        }
        map = new ArrayList[243];
        for(int i = 0; i < 243; i++){
            map[i] = new ArrayList<String>();
        }
    }

    public void printSolutions(){
        for(int i = 0; i < solutions.length; i++){
            System.out.println(solutions[i]);
        }
    }

    public int base10(int[] result){
        int base10 = 0;
        base10 += result[4];
        base10 += 3*result[3];
        base10 += 9*result[2];
        base10 += 27*result[1];
        base10 += 81*result[0];
        return base10;
    }

    public void play(){
        for(int i = 0; i < solutions.length; i++) {
            Wordle w = new Wordle(solutions[i]);
            int[] result = w.guess(guess);
            int base10 = base10(result);
            map[base10].add(w.getSolution());
        }
    }

    public void printMap(){
        for(int i = 0; i < 243; i++){
            for(int j = 0; j < map[i].size(); j++){
                System.out.print(map[i].get(j) + " ");
            }
            System.out.println();
        }
    }

    public ArrayList<String>[] getMap(){
        return map;
    }

    public String getGuess(){
        return guess;
    }

    public String[] getSolutions(){
        return solutions;
    }

}