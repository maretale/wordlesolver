public class Main {
    public static void main(String[] args) {
        Solver s1 = new Solver();
        s1.solve();
        /*s1.evaluateFirstGuesses();
        System.out.println();
        s1.sortScores(s1.getFirstGuesses());
        System.out.println();
        System.out.println("Average number of words left after first guess:");
        s1.printScores(s1.getFirstGuesses());
        System.out.println();

        s1.evaluateSecondGuesses();
        System.out.println();
        s1.sortScores(s1.getSecondGuesses());
        System.out.println();
        System.out.println("Average number of words left after second guess:");
        s1.printScores(s1.getSecondGuesses());

        s1.evaluateThirdGuesses();
        System.out.println();
        s1.sortScores(s1.getThirdGuesses());
        System.out.println();
        System.out.println("Average number of words left after third guess:");
        s1.printScores(s1.getThirdGuesses());*/
    }
}