import java.io.*;
import java.util.*;
public class Solver {
    private String[] guesses;
    private String[] solutions;
    private Guess[] firstGuesses;
    private Guess[] secondGuesses;
    private Guess[] thirdGuesses;
    private Guess[] fourthGuesses;
    private Guess[] fifthGuesses;
    private Guess[] currentGuess2;
    private Guess[][] currentGuess3;
    private Guess[][][] currentGuess4;
    private Guess[] currentGuess5;
    private Guess bestGuess1;
    private Guess[] bestGuess2;
    private Guess[][] bestGuess3;
    private Guess[][][] bestGuess4;
    private Guess[] bestGuess5;
    private Guess[] goodGuesses;
    public Solver(){
        try {
            File WordleSolutions = new File("WordleSolutions.txt");
            Scanner ss = new Scanner(WordleSolutions);
            File WordleGuesses = new File("WordleGuesses.txt");
            Scanner sg = new Scanner(WordleGuesses);
            solutions = new String[2309];
            for (int i = 0; i < 2309; i++) {
                solutions[i] = ss.nextLine();
            }
            guesses = new String[14855];
            for (int i = 0; i < 14855; i++) {
                guesses[i] = sg.nextLine();
            }
            Wordle.setAlphabet();
            FirstGuess.setSolutions();
            firstGuesses = new Guess[14855];
            secondGuesses = new Guess[14855];
            thirdGuesses = new Guess[14855];
            fourthGuesses = new Guess[14855];
            fifthGuesses = new Guess[14855];
            currentGuess2 = new Guess[243];
            currentGuess3 = new Guess[243][243];
            currentGuess4 = new Guess[243][243][243];
            currentGuess5 = new Guess[243];
            bestGuess1 = null;
            bestGuess2 = new Guess[243];
            bestGuess3 = new Guess[243][243];
            bestGuess4 = new Guess[243][243][243];
            bestGuess5 = new Guess[243];
            goodGuesses = new Guess[50];
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void solve(){
        //evaluateFirstGuesses();
        //System.out.println();
        //sortScores(getFirstGuesses());
        //System.out.println();
        //System.out.println("Average number of words left after first guess:");
        //printScores(getFirstGuesses());
       // System.out.println();

        for(int i = 74; i < 75/*getFirstGuesses().length*/; i++) {
            FirstGuess f = new FirstGuess(/*firstGuesses[i].getGuess()*/"adieu");
            f.play();
            for(int a = 0; a < 243; a++) {
                currentGuess2[a] = null;
                if (f.getMap()[a].size() > 2) {
                    evaluateSecondGuesses(f, a);
                    for(int x = 0; x < f.getMap()[a].size(); x++){
                        int index = getIndexOfGuess(f.getMap()[a].get(x));
                        secondGuesses[index].setScore(secondGuesses[index].getScore()-0.0001);
                    }
                    //System.out.println();
                    sortScores(getSecondGuesses());
                    //System.out.println();
                    //System.out.println("Average number of words left after second guess:");
                    //printScores(getSecondGuesses());

                    for (int j = 0; j < 15 /*50*/ /*getSecondGuesses().length*/; j++) {
                        SecondGuess s = new SecondGuess(secondGuesses[j].getGuess(), f, a);
                        s.play();
                        //s.printMap();
                        for(int b = 0; b < 243; b++){
                            currentGuess3[a][b] = null;
                            if (s.getMap()[b].size() > 2) {
                                evaluateThirdGuesses(s, b);
                                for(int x = 0; x < s.getMap()[b].size(); x++){
                                    int index = getIndexOfGuess(s.getMap()[b].get(x));
                                    thirdGuesses[index].setScore(thirdGuesses[index].getScore()-0.0001);
                                }
                                //System.out.println();
                                sortScores(getThirdGuesses());
                                //System.out.println();
                                //System.out.println("Average number of words left in pool " + b + " after third guess:");
                                //printScore(getThirdGuesses());

                                for(int k = 0; k < 5 /*40*/ /*getThirdGuesses().length*/; k++){
                                    ThirdGuess t = new ThirdGuess(thirdGuesses[k].getGuess(), s, b);
                                    t.play();
                                    boolean best3 = true;
                                    for(int c = 0; c < 243; c++) {
                                        currentGuess4[a][b][c] = null;
                                        if (t.getMap()[c].size() > 2) {
                                            best3 = false;
                                            evaluateFourthGuesses(t, c);
                                            for (int x = 0; x < t.getMap()[c].size(); x++) {
                                                int index = getIndexOfGuess(t.getMap()[c].get(x));
                                                fourthGuesses[index].setScore(fourthGuesses[index].getScore() - 0.0001);
                                            }
                                            //System.out.println();
                                            sortScores(getFourthGuesses());
                                            //System.out.println();
                                            //System.out.println(t.getMap()[c].size());
                                            //System.out.println("Average number of words left in pool " + c + " of guess " + k + " after fourth guess (" + thirdGuesses[k].getScore() + "):");
                                            //printScore(getFourthGuesses());

                                            for (int l = 0; l < 1/*getFourthGuesses().length*/; l++) {
                                                FourthGuess fo = new FourthGuess(fourthGuesses[l].getGuess(), t, c);
                                                fo.play();
                                                boolean best4 = true;
                                                for (int d = 0; d < 243; d++) {
                                                    currentGuess5[d] = null;
                                                    if (fo.getMap()[d].size() > 2) {
                                                        best4 = false;
                                                        evaluateFifthGuesses(fo, d);
                                                        for (int x = 0; x < fo.getMap()[d].size(); x++) {
                                                            int index = getIndexOfGuess(fo.getMap()[d].get(x));
                                                            fifthGuesses[index].setScore(fifthGuesses[index].getScore() - 0.0001);
                                                        }
                                                        //System.out.println();
                                                        sortScores(getFifthGuesses());
                                                        //System.out.println();
                                                        //System.out.println(fo.getMap()[d].size());
                                                        //System.out.println("Average number of words left in pool " + d + " of guess " + l + " after fifth guess:");
                                                        //printScore(getFifthGuesses());

                                                        FifthGuess fi = new FifthGuess(fifthGuesses[0].getGuess(), fo, d);
                                                        fi.play();
                                                        currentGuess5[d] = new Guess(fo.getGuess(), fo.getMap()[d].size()*10+6.0);
                                                        if(fi.getMap()[242].size() == 1){
                                                            currentGuess5[d] = new Guess(fo.getGuess(), fo.getMap()[d].size()*10+(5.0+6.0*(fo.getMap()[d].size()-1))/fo.getMap()[d].size());
                                                        }

                                                    }/*need to use currentGuess5*/ else if (fo.getMap()[d].size() == 2) {
                                                        currentGuess5[d] = new Guess(fo.getMap()[d].get(0), 25.5);
                                                    } else if (fo.getMap()[d].size() == 1) {
                                                        currentGuess5[d] = new Guess(fo.getMap()[d].get(0), 15.0);
                                                        if (d == 242) {
                                                            currentGuess5[d] = new Guess(fo.getMap()[d].get(0), 14.0);
                                                        }
                                                    }
                                                }
                                                if(currentGuess4[a][b][c] == null || averageTurn(currentGuess5) < currentGuess4[a][b][c].getScore()){
                                                    currentGuess4[a][b][c] = new Guess(fo.getGuess(), averageTurn(currentGuess5));
                                                }
                                                if (best4) {
                                                    l = 14855;
                                                }
                                            }/*need to use currentGuess4*/
                                            currentGuess4[a][b][c] = new Guess(t.getGuess(), averageTurn(currentGuess5));
                                        } else if (t.getMap()[c].size() == 2) {
                                            currentGuess4[a][b][c] = new Guess(t.getMap()[c].get(0), 24.5);
                                        } else if (t.getMap()[c].size() == 1) {
                                            currentGuess4[a][b][c] = new Guess(t.getMap()[c].get(0), 14.0);
                                            if (c == 242) {
                                                currentGuess4[a][b][c] = new Guess(t.getMap()[c].get(0), 13.0);
                                            }
                                        }
                                    }
                                    if(currentGuess3[a][b] == null || averageTurn(currentGuess4[a][b]) < currentGuess3[a][b].getScore()){
                                        currentGuess3[a][b] = new Guess(t.getGuess(), averageTurn(currentGuess4[a][b]));
                                    }
                                    if(best3){
                                        k=14855;
                                    }
                                }
                                //currentGuess3[a][b] = new Guess(t.getGuess(), averageTurn(bestGuess4[a][b]));
                                //System.out.println("Average turn of completion for " + t.getGuess() + ":  " + currentGuess3[a][b].getScore()%10);
                            }
                            else if(s.getMap()[b].size()==2){
                                currentGuess3[a][b] = new Guess(s.getMap()[b].get(0), 23.5);
                            }
                            else if(s.getMap()[b].size()==1){
                                currentGuess3[a][b] = new Guess(s.getMap()[b].get(0), 13.0);
                            }
                        }
                        if(currentGuess2[a] == null || averageTurn(currentGuess3[a]) < currentGuess2[a].getScore()){
                            currentGuess2[a] = new Guess(s.getGuess(), averageTurn(currentGuess3[a]));
                            for(int b = 0; b < 243; b++){
                                bestGuess3[a][b] = currentGuess3[a][b];
                            }
                        }
                        //System.out.println();
                        //System.out.println("Average turn of completion for " + s.getGuess() + ":  " + averageTurn(currentGuess3[a])%10);
                        //System.out.println();
                    }
                }else if(f.getMap()[a].size()==2){
                    currentGuess2[a] = new Guess(f.getMap()[a].get(0), 22.5);
                }
                else if(f.getMap()[a].size()==1){
                    currentGuess2[a] = new Guess(f.getMap()[a].get(0), 12.0);
                    if(a==242){
                        currentGuess2[a] = new Guess(f.getMap()[a].get(0), 11.0);
                    }
                }
                if(f.getMap()[a].size()!=0) {
                    //System.out.println("(pool " + a + ") Average turn of completion for " + currentGuess2[a].getGuess() + ":  " + currentGuess2[a].getScore() % 10);
                }
            }
            if(bestGuess1 == null || averageTurn(currentGuess2) < bestGuess1.getScore()){
                bestGuess1 = new Guess(f.getGuess(), averageTurn(bestGuess2));
            }
            //System.out.println();
            System.out.println("Average turn of completion for " + f.getGuess() + ":  " + averageTurn(currentGuess2)%10);
            //goodGuesses[i] = new Guess(f.getGuess(), averageTurn(currentGuess2)%10);
        }
        sortScores(goodGuesses);
        System.out.println();
        System.out.println("Average turn of completion when used as the first guess:");
        printScores(goodGuesses);
        System.out.println();
        System.out.println("The best starting word is " + bestGuess1.getGuess() + " with an average completion time of " + bestGuess1.getScore() + " turns.");
    }

    public double averageTurn(Guess[] g){
        double average = 0.0;
        int num = 0;
        int total = 0;
        for(int i = 0; i < 243; i++){
            if(g[i]!=null) {
                num = (int) (g[i].getScore() / 10);
                total += num;
                average += (g[i].getScore()%10) * num;
            }
        }
        average = average/total + total*10;
        return average;
    }
    public int getIndexOfGuess(String s){
        int index = -1;
        for(int i = 0; i < 14855; i++){
            if(guesses[i].equals(s)){
                index = i;
            }
        }
        return index;
    }
    public double findAverage(ArrayList<String>[] map, int n){
        double average = 0.0;
        for(int i = 0; i < 243; i++){
            average += map[i].size()*((double)map[i].size()/n);
        }
        return average;
    }

    public double scoreFirstGuess(FirstGuess f){
        return findAverage(f.getMap(), 2309);
    }

    public void evaluateFirstGuesses(){
        for(int i = 0; i < 14855; i++){
            FirstGuess f = new FirstGuess(guesses[i]);
            f.play();
            double score = scoreFirstGuess(f);
            Guess g = new Guess(guesses[i], score);
            firstGuesses[i]=g;
            System.out.println(guesses[i] + ":  " + score);
        }
    }

    public void sortScores(Guess[] g){
        MergeSort.sort(g, 0, 14854);
    }
    public void printScores(Guess[] g){
        for(int i = 0; i < 14855; i++){
            System.out.println(g[i].getGuess() + ":  " + g[i].getScore());
        }
    }
    public void printScore(Guess[] g){
        System.out.println(g[0].getGuess() + ":  " + g[0].getScore());
    }

    public Guess[] getFirstGuesses(){
        return firstGuesses;
    }

    public void evaluateSecondGuesses(FirstGuess f, int n){
        for(int i = 0; i < 14855; i++){
            SecondGuess s = new SecondGuess(guesses[i], f, n);
            s.play();
            double score = scoreSecondGuess(s);
            Guess g = new Guess(guesses[i], score);
            secondGuesses[i]=g;
        }
    }

    public double scoreSecondGuess(SecondGuess s){
        return findAverage(s.getMap(), s.getSolutions().length);
    }

    public Guess[] getSecondGuesses(){
        return secondGuesses;
    }

    public void evaluateThirdGuesses(SecondGuess s, int n){
        for(int i = 0; i < 14855; i++){
            ThirdGuess t = new ThirdGuess(guesses[i], s, n);
            t.play();
            double score = scoreThirdGuess(t);
            Guess g = new Guess(guesses[i], score);
            thirdGuesses[i]=g;
        }
    }

    public double scoreThirdGuess(ThirdGuess t){
        return findAverage(t.getMap(), t.getSolutions().length);
    }

    public Guess[] getThirdGuesses(){
        return thirdGuesses;
    }

    public void evaluateFourthGuesses(ThirdGuess t, int n){
        for(int i = 0; i < 14855; i++){
            FourthGuess f = new FourthGuess(guesses[i], t, n);
            f.play();
            double score = scoreFourthGuess(f);
            Guess g = new Guess(guesses[i], score);
            fourthGuesses[i]=g;
        }
    }

    public double scoreFourthGuess(FourthGuess f){
        return findAverage(f.getMap(), f.getSolutions().length);
    }

    public Guess[] getFourthGuesses(){
        return fourthGuesses;
    }

    public void evaluateFifthGuesses(FourthGuess fo, int n){
        for(int i = 0; i < 14855; i++){
            FifthGuess fi = new FifthGuess(guesses[i], fo, n);
            fi.play();
            double score = scoreFifthGuess(fi);
            Guess g = new Guess(guesses[i], score);
            fifthGuesses[i]=g;
        }
    }

    public double scoreFifthGuess(FifthGuess f){
        return findAverage(f.getMap(), f.getSolutions().length);
    }

    public Guess[] getFifthGuesses(){
        return fifthGuesses;
    }
}
